#include "ring.h"
#include "uart.h"

void char_count(uint8_t  c_value);
void fib();
