#include "pin_mux.h"
#include "MKL25Z4.h"

void led_init();
void led_toggle();


